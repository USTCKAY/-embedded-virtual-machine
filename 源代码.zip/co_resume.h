#pragma once
void co_resume(coctx_t* ctx1,coctx_t* ctx2,coctx_t* ctx3,char* sp,coctx_param_t* para);
void co_swap_out(coctx_t* ctx1,coctx_t* ctx2,coctx_t* ctx3,char* sp);
void co_swap_in(coctx_t* ctx1,coctx_t* ctx2,coctx_t* ctx3,char* sp);
