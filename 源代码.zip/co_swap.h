#pragma once
void swap_coctx_init(coctx_t* ctx1,coctx_t* ctx2);
