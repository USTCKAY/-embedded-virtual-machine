#include "coroutine.h"
//sw_coqueue newQueue;//全局队列
sw_schedule *sw_sc;//定义的调度器对象
sw_process *sw_pr[64];//定义的执行器对象
sw_coroutine *sw_co;//定义的协程
int STOP_SIGNAL = 0;
int current_co=0;//当前执行函数的协程
