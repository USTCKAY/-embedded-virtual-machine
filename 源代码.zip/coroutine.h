#ifndef _COROUTINE_H
#define _COROUTINE_H

#define DEFAULT_COROUTINE 0
#define CO_RUNNING 0
#define CO_WAIT 1
#define CO_NEW 2
#define CO_DONE 3

//任务队列存储结构
typedef struct queue{
    struct sw_coroutine *co;//协程控制块
    struct queue *next;//下一个协程控制块
}coqueue;

typedef struct {
    coqueue *front,*rear;
}sw_coqueue;

//执行器结构体
typedef struct {
    int process_id;
    int running;//当前正在运行的协程id
    //关联的队列
    sw_coqueue runnableQueue;
    sw_coqueue waitQueue;
    sw_coqueue newQueue;
    //栈信息
}sw_process;


//调度器结构体
typedef struct{
    sw_process *pr[64];//关联的执行器
    //主函数上下文
}sw_schedule;
/*用extern在这里只声明不定义，定义在master_schedule.c中*/
typedef struct 
{
	int s1;
	int s2;
}coctx_param_t;

typedef struct 
{
	void *regs[ 32 ];
	int ss_size;
	char *ss_sp;
	coctx_param_t* param;	
}coctx_t;

//协程结构体
typedef struct{
    //协程运行的函数
  //  void (*func)();
    coctx_t* coctx;
    int coroutine_id;
    int status;//状态
    int sw_process_id;//当前归属的执行器，就是slave_id
}sw_coroutine;

extern sw_schedule *sw_sc;//定义的调度器对象
extern sw_process *sw_pr[64];//定义的执行器对象
extern sw_coroutine *sw_co;//定义的协程
extern int STOP_SIGNAL;

#endif
