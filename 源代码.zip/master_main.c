#include <stdlib.h>
#include <stdio.h>
#include <athread.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdbool.h>
#include <stdint.h>
#include <pthread.h>
#include <sys/time.h>
#include "master_schedule.h"
#include "coroutine.h"

extern sw_schedule *sw_sc;//定义的调度器对象
extern sw_process *sw_pr[64];//定义的执行器对象
extern sw_coroutine *sw_co;//定义的协程
extern int STOP_SIGNAL;

//extern SLAVE_FUN(chunk)(int start,int end);
extern SLAVE_FUN(conv)(int s,int e);
extern SLAVE_FUN(swgo_pr_start)(sw_process *sw_pr[]);

int num[1280]={0};
int cost[1280]={5};
int mtag[32]={0};
int main()
{
	struct timeval t1,t2,t3;
	printf("\n");
	int i,j;
	int stack_size;
	int swco_num=1280;
	//penv_slave0_cycle_init();
	swgo_init();//协程库初始化

	pthread_t sc_id;
	int ret=pthread_create(&sc_id,NULL,&swgo_sc_start,NULL);
	if(ret){
		printf("creat thread error");
	}

    void (*function)(int row,int col)=&slave_conv;
	printf("this is conv address\t%p\n",function);
	
	gettimeofday(&t1,NULL);
    create_routine(function,swco_num);//swco_num个协程创建
	gettimeofday(&t2,NULL);
	swgo_func();//分配
	swgo_sc_stop(sc_id);//协程库关闭回收资源
	gettimeofday(&t3,NULL);

	printf("\ntime:%ld\n",t3.tv_usec-t1.tv_usec);
	printf("64:%d\n",num[64]);
	printf("1153:%d\n",num[1153]);
	printf("\n");
    return 0;
}
