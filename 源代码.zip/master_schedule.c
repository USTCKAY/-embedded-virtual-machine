#include <stdlib.h>
#include <stdio.h>
#include <athread.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdbool.h>
#include <stdint.h>
#include <pthread.h>
#include "master_schedule.h"
#include "coroutine.h"

extern sw_schedule *sw_sc;//定义的调度器对象
extern sw_process *sw_pr[64];//定义的执行器对象
extern sw_coroutine *sw_co;//定义的协程
extern int STOP_SIGNAL;
//extern struct timeval t,t1,t2,t3,t4,t5;
extern SLAVE_FUN(conv)(int s,int e);
extern SLAVE_FUN(swgo_pr_start)(sw_process *sw_pr[]);

void swgo_init()//1
{
    sc_pr_init();
    athread_init();//athread初始化
    penv_slave0_cycle_init();
    athread_spawn(swgo_pr_start,sw_pr);
}


void schedule_routine();
void swgo_sc_start()//2
{
    schedule_routine();//队列为空，给从核发送信号让执行器停止
}


void create_routine(void (*function)(int,int),int swco_num);//3


void first_allocation();
void swgo_func()//4
{
    first_allocation();
}


void swgo_sc_stop(pthread_t sc_id)//5
{
    //STOP_SIGANL
    athread_join();
    pthread_join(sc_id,NULL);
}

//队列初始化
void InitQueue(sw_coqueue *Q)
{
    Q->front=Q->rear=(coqueue *)malloc(sizeof(coqueue));
    Q->front->next=NULL;
    Q->rear=Q->front;
}
//入队
void EnQueue(sw_coqueue *Q,sw_coroutine *x)
{
    coqueue *s=(coqueue *)malloc(sizeof(coqueue));
    s->co=x;
    s->next=NULL;
    Q->rear->next=s;
    Q->rear=s;
}
//队列每个元素输出
void QueuePrint(sw_coqueue *Q)
{
	coqueue *p=Q->front->next;
	while(p)
	{
        //printf("coqueue->co->coroutine_id=%d\n",p->co->coroutine_id);
		//printf("coqueue—>co->status=%d\n",p->co->status);
		p=p->next; 
	}
	//return true;
}
//出队
sw_coroutine *DeQueue(sw_coqueue *Q)
{
    sw_coroutine *x;
    if(Q->rear==Q->front)
    {
        return false;//空队列
    }
    coqueue *p;
    p=Q->front->next;
    x=p->co;
    Q->front->next=p->next;
    if(Q->rear==p)
    {
        Q->rear=Q->front;//若原队列只有一个结点，则删除后变空
    }
    free(p);
    return x;
}
//队列中协程数目
int CountQueue(sw_coqueue *Q)
{
    coqueue *p=Q->front->next;
    int count=0;
    while(p)
    {
        count++;
        p=p->next;
    }
    return count;
}
//判队空
int EmptyQueue_sc(sw_coqueue *Q)
{
    if(Q->front==Q->rear) return 1;
    else return 0;
}
//取第一个协程
sw_coroutine *firstcoroutine(sw_coqueue *Q)
{
    sw_coroutine *x;
    if(Q->rear==Q->front)
    {
        return 0;//空队列
    }
    x=Q->front->next->co;
    return x;
}
void create_routine(void (*function)(int,int),int swco_num)//创建协程
{
    int i;
    for(i=0;i<swco_num;i++){
        sw_co=( sw_coroutine *)malloc(sizeof( sw_coroutine));
        coctx_t* sw_coctx=malloc(sizeof(coctx_t));
        coctx_param_t* para=malloc(sizeof(coctx_param_t));
        char* sp=(char*)malloc(sizeof(char)*4096);
        sw_coctx->regs[26]=&(slave_conv);
        sw_coctx->regs[16]=para;
        sw_coctx->ss_sp=sp;
        sw_coctx->param=para;
        sw_co->coroutine_id=i;
        sw_co->status=CO_NEW;
        sw_co->coctx=sw_coctx;
    
        //分配队列
        int j=i%64;
        sw_co->sw_process_id=j;
    
        EnQueue(&sw_pr[j]->newQueue,sw_co);
    }

}

void first_allocation()//首次分配
{
    int num_run=0,num_new=0;
    int num_wait=0;
    int i;
  //  gettimeofday(&t3,NULL);
    //这里应该全部分配完再让从核执行
    for(i=0;i<64;i++)
    {
        num_run=CountQueue(&sw_pr[i]->runnableQueue);
        num_wait=CountQueue(&sw_pr[i]->waitQueue);
        num_new=CountQueue(&sw_pr[i]->newQueue);
        if(num_new==0)
        {
            continue;
        }
        while(num_run<20)
        {
            if(num_new==0)
            {
                break;
            }
            sw_coroutine *newfirst=DeQueue(&sw_pr[i]->newQueue);
	    newfirst->status=CO_RUNNING;
            EnQueue(&sw_pr[i]->runnableQueue,newfirst);
            num_run++;
            //num_run=CountQueue(&sw_pr[i]->runnableQueue);
        }
    }
    //gettimeofday(&t4,NULL);
}

void schedule_routine()//调度方式，监控队列状态
{
    int num_run=0,num_wait=0,num_new=0;
    int i;
    int empty_num=0;
    int break_signal=0;
    while(!break_signal)
    {
        for(i=0;i<64;i++)
        {
            if(empty_num==64)
            {
                break_signal=1;
                STOP_SIGNAL=1;
                break;
            }
            num_run=CountQueue(&sw_pr[i]->runnableQueue);
	        num_new=CountQueue(&sw_pr[i]->newQueue);
	        num_wait=CountQueue(&sw_pr[i]->waitQueue);
            if(num_run==0 && num_new==0 && num_wait==0)
            {
                empty_num++;
            }
        }
    }
}
void sc_pr_init()
{
    //调度器
    sw_sc=( sw_schedule *)malloc(sizeof( sw_schedule));

    //执行器
    int i=0;
    for(i;i<64;i++)//64个执行器
    {
        sw_pr[i]=( sw_process *)malloc(sizeof( sw_process));
        sw_pr[i]->process_id=i;
        InitQueue(&sw_pr[i]->newQueue);
        InitQueue(&sw_pr[i]->runnableQueue);
	    InitQueue(&sw_pr[i]->waitQueue);
        sw_sc->pr[i]=sw_pr[i];
    }
}

