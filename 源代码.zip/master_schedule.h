
void swgo_init();
void swgo_func();//首次分配
void create_routine(void (*function)(int,int),int swco_num);
//void first_allocation();
void swgo_sc_start();//调度器监控全部队列状态
void swgo_sc_stop();