#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "slave.h"
#include "coroutine.h"
#include "co_resume.h"
#include "co_swap.h"

__thread_local volatile unsigned long put_reply,get_reply;
__thread_local stag=0;

//extern int cost[1280];
extern sw_schedule *sw_sc;//定义的调度器对象
extern sw_process *sw_pr[64];//定义的执行器对象
extern sw_coroutine *sw_co;//定义的协程
extern int STOP_SIGNAL;
extern int num[1280];
extern int mtag[32];
extern int cost[1280];
extern __thread_local coctx_t bctx_base;
extern __thread_local coctx_t bctx_temp;
extern __thread_local char* sp;
extern __thread_local coctx_t* ctx_1,ctx_2;
void conv(coctx_param_t* para)
{	
	int id=para->s1;
	int a=para->s1;
	int b=para->s2;
	if(id==64){//slave0
	    get_reply=0;
	    athread_get(0,&mtag[0],&stag,4,&get_reply,0,0,0);
	    while(get_reply!=1);
	    int s1;
	    while(stag!=1){
			s1=1;
			put_reply=0;
			athread_put(0,&s1,&cost[id],4,&put_reply,0,0);
			while(put_reply!=1);

			co_swap_out(&bctx_temp,ctx_1,&bctx_base,sp);//save

			printf("swapin");
			break;
			get_reply=0;
			athread_get(0,&mtag[0],&stag,4,&get_reply,0,0,0);
			while(get_reply!=1);
	    }
	    num[id]=a+b+1;
		s1=3;
		put_reply=0;
		athread_put(0,&s1,&cost[id],4,&put_reply,0,0);
		while(put_reply!=1);
	}
	else if(id==1153){//slave1
		int s2=3;
	    num[id]=a+b+1;
	    stag=1;
	    put_reply=0;
	    athread_put(0,&stag,&mtag[0],4,&put_reply,0,0);
	    while(put_reply!=1);

		put_reply=0;
		athread_put(0,&s2,&cost[id],4,&put_reply,0,0);
		while(put_reply!=1);

	}
	else{
		int s3=3;
		num[id]=a+b;
		put_reply=0;
		athread_put(0,&s3,&cost[id],4,&put_reply,0,0);
		while(put_reply!=1);

	}
}

