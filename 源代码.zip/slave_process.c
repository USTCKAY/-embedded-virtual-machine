#include <stdio.h>
#include <stdlib.h>
#include "slave.h"
#include "coroutine.h"
#include "co_resume.h"
#include "co_swap.h"

extern sw_schedule *sw_sc;//定义的调度器对象
extern sw_process *sw_pr[64];//定义的执行器对象
extern sw_coroutine *sw_co;//定义的协程
extern int STOP_SIGNAL;
extern int mtag[32];
extern int cost[1280];
//从核变量定义
__thread_local volatile unsigned long get,put;
__thread_local int my_id;
__thread_local int stag2=0;

__thread_local coctx_t bctx_base;
__thread_local coctx_t bctx_temp;
__thread_local char* sp;
__thread_local coctx_t* ctx_1,ctx_2;
//判队空
int EmptyQueue(sw_coqueue *Q)
{
    if(Q->front==Q->rear) return 1;
    else return 0;
}
//出队
sw_coroutine *firstcoroutine(sw_coqueue *Q)
{
	//printf("DeQueue\n");
    sw_coroutine *x;
    if(Q->rear==Q->front)
    {
        return 0;//空队列
    }
    coqueue *p;
    p=Q->front->next;
    x=p->co;
    Q->front->next=p->next;
    if(Q->rear==p)
    {
        Q->rear=Q->front;//若原队列只有一个结点，则删除后变空
    }
    free(p);
    return x;
}
//获取队头协程
sw_coroutine *front(sw_coqueue *Q)
{
    sw_coroutine *x;
    if(Q->rear==Q->front){
        return 0;
    }
    x=Q->front->next->co;
    return x;
}
//入队尾
void EnQueue(sw_coqueue *Q,sw_coroutine *x)
{
    coqueue *s=(coqueue *)malloc(sizeof(coqueue));
    s->co=x;
    s->next=NULL;
    Q->rear->next=s;
    Q->rear=s;
}
//释放第一个协程资源
void co_free(sw_coroutine *x)
{
    free(x);
}
int pop(sw_coqueue Q)
{

}
void swgo_pr_start(sw_process *sw_pr[])
{
    sp=(char*)ldm_malloc(sizeof(char)*1024*4);
    coctx_param_t* para;
    int s,e;
    int co_id;
    int z;
    my_id=athread_get_id(-1);
    
    while(!STOP_SIGNAL)
    {
        get=0;//判断另一个从核有没有运行到需要的地方
        athread_get(0,&mtag[0],&stag2,4,&get,0,0,0);
        while(get!=1);

        if(!EmptyQueue(&sw_pr[my_id]->waitQueue) && stag2==1){
		    printf("o\n");
                sw_coroutine *waitco =firstcoroutine(&sw_pr[my_id]->waitQueue);
                printf(" id:%d\n",waitco->coroutine_id);
                EnQueue(&sw_pr[my_id]->runnableQueue,waitco);
		
        }
        if(!EmptyQueue(&sw_pr[my_id]->runnableQueue))
        {
            sw_coroutine *runco=firstcoroutine(&sw_pr[my_id]->runnableQueue);

            if(runco->status==CO_RUNNING){
                co_id=runco->coroutine_id;
                s=co_id;//行起始
                e=0;//列起始
                runco->coctx->param->s1=s;
                runco->coctx->param->s2=e;
		        ctx_1=runco->coctx;
                co_resume(runco->coctx,&bctx_base,&bctx_temp,sp,para);
		//切回这里
                runco->status=cost[co_id];
                if(runco->status==CO_WAIT){
                    printf("c\n");
                    printf("%d\n",runco->coroutine_id);
                    EnQueue(&sw_pr[my_id]->waitQueue,runco);
                    sw_coroutine *test=front(&sw_pr[my_id]->waitQueue);
                    printf("e%d\n",test->coroutine_id);
                    continue;
                }
                else if(runco->status==CO_DONE){
                    co_free(runco);
                    continue;
                }
                continue;

            }
            else if(runco->status==CO_WAIT){//run队列中的wait是曾经阻塞的协程
                co_swap_in(&bctx_base,runco->coctx,&bctx_temp,sp);
            }
        }
    }
}
