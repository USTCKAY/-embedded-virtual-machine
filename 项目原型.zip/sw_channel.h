#include <stdio.h>
#include <inttypes.h>
#include <stdlib.h>
#include <stdbool.h>

#define RATE 1450000000
enum PATTERN{
    MANY_TO_MANY ,ONE_TO_ONE ,ONE_TO_MANY,MANY_TO_ONE
};
//通道结构体
typedef struct {
    uint8_t *buffer;//存放消息的缓冲区
    uint32_t capacity;//缓冲区元素数量
    uint32_t elem_size;//缓冲区元素大小
    uint32_t read;//读下标
    uint32_t to_read;//读下标，与read在有序读中发挥作用
    uint32_t write;//写下标
    uint32_t to_write;//写下标，与write在有序写中发挥作用
    bool closed;//通道是否关闭
    // sw_list * _wq;//等待发送的线程号
    // sw_list * _rq;//等待接收的线程号
    enum PATTERN pattern;
    // uint32_t (*push_t)(channel*chan,uint8_t* buf);
}channel;

typedef struct {
    uint8_t *buffer;
    uint32_t size;
    uint32_t elem_size;
    uint32_t read;
    uint32_t write;
    uint32_t toRead;
}o2o_channel;


//创建通道并初始化
#define  channel_init(capacity, elem_size) channel_init_p(capacity, elem_size, MANY_TO_MANY)
channel* channel_init_p(uint32_t capacity,uint32_t elem_size, enum PATTERN pattern);
//向通道发送消息
uint32_t push(channel *chan,uint8_t *buf);
//从通道接收消息
uint32_t pop(channel *chan,uint8_t *buf);
//关闭通道
bool _close(channel *chan);
//通道是否为空
bool empty(channel *chan);
//通道是否为满
bool full(channel *chan);
void push_s(int i);
int pop_s();
//唤醒一个等待的线程/协程
bool notify(channel* chan);
//唤醒所有等待的线程/协程
bool notif_all(channel *chan);
//清除缓冲区的所有数据，并释放所有等待的线程/协程
bool clear(channel *chan);

