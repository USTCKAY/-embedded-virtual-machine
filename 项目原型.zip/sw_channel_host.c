#include"sw_channel.h"
#include<stdlib.h>

channel* channel_init_p(uint32_t capacity,uint32_t elem_size,enum PATTERN pattern){
    channel* chan = (channel*)malloc(sizeof(channel));
    uint8_t * buf = (uint8_t*)malloc(capacity * elem_size);
    chan->buffer = buf;
    chan->closed= 0;
    chan->read = 0;
    chan->to_read =0;
    chan->write=0;
    chan->to_write =0;
    chan->elem_size =elem_size;
    chan->capacity = capacity;
    chan->pattern = pattern;
    return chan;
}
bool full(channel * chan){
    int write = chan->write;
    int read = chan->read;
    if(write-read == chan->capacity){
        return 1;
    }
    return 0;
}
bool empty(channel * chan){
    int write = chan->to_write;
    int read = chan->read;
    if(write-read == 0){
        return 1;
    }
    return 0;
}



uint32_t many_push(channel *chan, uint8_t *buf)
{
    // uint32_t next;
    int ok;
    uint32_t capacity = chan->capacity;
    uint32_t elem_size = chan->elem_size;
    uint32_t temp;
    int notified = 1;
    do {
        if (full(chan)){
            return 1;
        }
        temp = chan->write;
        if(temp != chan->to_write)
            continue;

        ok = __sync_bool_compare_and_swap(&chan->write, temp, temp+1);
    } while (!ok);
    //复制数据
    if (full(chan)){
        return 1;
    }
    memcpy(chan->buffer+(temp%capacity)*elem_size, buf,elem_size);
    asm volatile ("":::"memory");
    __sync_bool_compare_and_swap(&chan->to_write, temp, temp+1);

    return 0;
}

uint32_t many_pop(channel * chan,uint8_t *buf){
    uint32_t elem_size = chan->elem_size;
    uint32_t capacity = chan->capacity;
    // uint32_t next;
    uint32_t temp;
    int notified = 1;
    int ok;
    do {
        if (empty(chan)){
            // printf("empty1");
            return 1;
        }
        temp = chan->read;
        if(temp != chan->to_read)
            continue;
        
        ok = __sync_bool_compare_and_swap(&chan->read, temp, temp+1);
    } while (!ok);
        // if (empty(chan)){
        //     printf("empty2");
        //     return 1;
        // }
        //需要比较to_write与temp
        if(chan->to_write == temp){
            return 1;
        }
    memcpy(buf,chan->buffer+(temp%capacity)*elem_size, elem_size);
    // q->msgs[head & mask] = m;
    // asm volatile ("":::"memory");
    __sync_bool_compare_and_swap(&chan->to_read, temp, temp+1);
    return 0;

}
//只有一个生产者
uint32_t one_push(channel* chan,uint8_t* buf){
    // printf("one push");
    int notified = 1;
    while(notified){
        int capacity = chan->capacity;
        int elem_size = chan->elem_size;
        if(full(chan)){
            continue;
        }else{
            memcpy(chan->buffer+(chan->write%capacity)*elem_size, buf,elem_size);
            chan->write++;
            return 0;
        }
    }
}

//只有一个消费者
uint32_t one_pop(channel* chan,uint8_t* buf){
    int notified = 1;
    while(notified){
        int capacity = chan->capacity;
        int elem_size = chan->elem_size;
        if(empty(chan)){
            continue;
        }
        else{
            memcpy(buf,chan->buffer+(chan->read%capacity)*elem_size,elem_size);
            chan->read++;
            return 0;
        }
    }
}





bool clear(channel *chan){
    chan->read = 0;
    chan->to_read =0;
    chan->write = 0;
    chan->to_write = 0;
    // notif_all(chan);
}


//根据通道的模式选择对应的push模式，只有一个生产者时使用one_push，多个生产者时使用many_push
uint32_t push(channel* chan,uint8_t *buf){

    switch (chan->pattern){
    case MANY_TO_MANY:
    case MANY_TO_ONE:
        many_push(chan,buf);
        break;
    case ONE_TO_MANY:
    case ONE_TO_ONE:
        one_push(chan,buf);
        break;
    default:
        break;
    }
}
//根据通道的模式选择对应的pop模式，只有一个消费者时使用one_pop，多个生产者时使用many_pop
uint32_t pop(channel* chan,uint8_t *buf){
    switch (chan->pattern){
    case MANY_TO_MANY:
    case ONE_TO_MANY:
        many_pop(chan,buf);
        break;
    case MANY_TO_ONE:
    case ONE_TO_ONE:
        one_pop(chan,buf);
        break;
    default:
        break;
    }
}
