#include"sw_channel.h"
#include<stdlib.h>
#include "unistd.h"
#include "slave.h"
channel* channel_init_p(uint32_t capacity,uint32_t elem_size,enum PATTERN pattern){
    channel* chan = (channel*)malloc(sizeof(channel));
    uint8_t * buf = (uint8_t*)malloc(capacity * elem_size);
    chan->buffer = buf;
    chan->closed= 0;
    chan->read = 0;
    chan->to_read =0;
    chan->write=0;
    chan->to_write =0;
    chan->elem_size =elem_size;
    chan->capacity = capacity;
    chan->pattern = pattern;
    return chan;
}


bool full(channel * chan){
    int write = chan->write;
    int read = chan->read;
    if(write-read == chan->capacity){
        return 1;
    }
    return 0;
}
bool empty(channel * chan){
    int write = chan->write;
    int read = chan->read;
    if(write-read == 0){
        return 1;
    }
    return 0;
}

// int chan_wait(){
// #ifdef _COROUTINE_H
//     co_swap_out();
// #else
//     return 1;
// }

//有多个生产者，需要保证写不覆盖
uint32_t many_push(channel* chan,uint8_t *buf){
    uint32_t elem_size = chan->elem_size;
    int temp;
    int notified = 1;
    while(notified){
        if(full(chan)){
            return 1;
        }
        temp = chan->write;
        if (temp==chan->to_write){
            updt_addw(1,&(chan->write));
        }else{
            continue;
        }
        if(chan->write == temp+1){
            if(full(chan)){
                return 1;
            }
            memcpy(chan->buffer+(temp%chan->capacity)*elem_size, buf,elem_size);
            updt_addw(1,&chan->to_write);
            return 0;
        }else{
            updt_addw(-1,&chan->write);
            continue;
        }
    }
    return 1;
}

//有多个消费者，需要保证不会重复读
uint32_t many_pop(channel * chan,uint8_t *buf){
    uint32_t elem_size = chan->elem_size;
    int temp;
    int notified = 1;
    while(notified){
        if(empty(chan)){
            return 1;
        }
        temp = chan->read;
        if (temp==chan->to_read){
            updt_addw(1,&(chan->read));
        }else{
            continue;
        }
        if(chan->read == temp+1){
            if(temp != chan->to_read)
                continue;
            memcpy(buf,chan->buffer+(temp%chan->capacity)*elem_size,elem_size);
            updt_addw(1,&chan->to_read);
            return 0;
        }else{
            updt_addw(-1,&chan->read);
            continue;
        }
    }
}





bool clear(channel *chan){
    chan->read = 0;
    chan->to_read =0;
    chan->write = 0;
    chan->to_write = 0;
    // notif_all(chan);
}

//只有一个生产者
uint32_t one_push(channel* chan,uint8_t* buf){
    int notified = 1;
    while(notified){
        int capacity = chan->capacity;
        int elem_size = chan->elem_size;
        if(full(chan)){
            continue;
        }else{
            memcpy(chan->buffer+(chan->write%capacity)*elem_size, buf,elem_size);
            chan->write++;
            return 0;
        }
    }
}
//只有一个消费者
uint32_t one_pop(channel* chan,uint8_t* buf){
    int notified = 1;
    while(notified){
        int capacity = chan->capacity;
        int elem_size = chan->elem_size;
        if(empty(chan)){
            continue;
        }else{
            memcpy(buf,chan->buffer+(chan->read%capacity)*elem_size,elem_size);
            chan->read++;
            return 0;
        }
    }
}

//根据通道的模式选择对应的push模式，只有一个生产者时使用one_push，多个生产者时使用many_push
uint32_t push(channel* chan,uint8_t *buf){

    switch (chan->pattern){
    case MANY_TO_MANY:
    case MANY_TO_ONE:
        many_push(chan,buf);
        break;
    case ONE_TO_MANY:
    case ONE_TO_ONE:
        one_push(chan,buf);
        break;
    default:
        break;
    }
}
//根据通道的模式选择对应的pop模式，只有一个消费者时使用one_pop，多个生产者时使用many_pop
uint32_t pop(channel* chan,uint8_t *buf){
    switch (chan->pattern){
    case MANY_TO_MANY:
    case ONE_TO_MANY:
        many_pop(chan,buf);
        break;
    case MANY_TO_ONE:
    case ONE_TO_ONE:
        one_pop(chan,buf);
        break;
    default:
        break;
    }
}
